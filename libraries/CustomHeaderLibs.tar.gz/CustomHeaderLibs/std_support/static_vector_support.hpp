// Author:  Mario S. Könz <mskoenz@gmx.net>
// Date:    14.06.2013 20:43:42 EDT
// File:    static_vector_support.hpp

 /* This program is free software. It comes without any warranty, to
  * the extent permitted by applicable law. You can redistribute it
  * and/or modify it under the terms of the Do What The Fuck You Want
  * To Public License, Version 2, as published by Sam Hocevar. See
  * http://www.wtfpl.net/ or COPYING for more details. */
  
#ifndef __STATIC_VECTOR_SUPPORT_HEADER
#define __STATIC_VECTOR_SUPPORT_HEADER

//use a std::vector<T> as conterpart of the ustd::static_vector<T, N>

#endif //__STATIC_VECTOR_SUPPORT_HEADER
